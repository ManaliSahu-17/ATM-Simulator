
package bank.management.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;


public class SignupThree extends JFrame implements ActionListener {
    JRadioButton b1,b2,b3,b4;
    JCheckBox c1,c2,c3,c4,c5,c6,c7;
    JButton submit,cancel;
    JLabel type,card,number,ncard,pin,pnumber,npin,service;
    String formno;
    String name;
    
   SignupThree(String formno,String name){
       this.name=name;
       this.formno=formno;
       setLayout(null);
       
       
       ImageIcon im1 = new ImageIcon(ClassLoader.getSystemResource("icons/form1.jpg"));
        Image im2=im1.getImage().getScaledInstance(850,800,Image.SCALE_DEFAULT);
        ImageIcon im3=new ImageIcon(im2);
        JLabel imimage= new JLabel(im3);
        imimage.setBounds(0,0,850,800);
        add(imimage);

       
       
       
       
       
       
       
      
      
       JLabel l1=new JLabel("Account Details"+"    "+formno);
       l1.setFont(new Font("Raleway",Font.BOLD,25));
       l1.setBounds(280,10,400,40);
       imimage.add(l1);
       
         type=new JLabel("Account Type");
       type.setFont(new Font("Raleway",Font.BOLD,18));
       type.setBounds(100,40,400,40);
        imimage.add(type);
       
       b1=new JRadioButton("Saving Account");
       b1.setFont(new Font("Raleway",Font.BOLD,16));
       b1.setBackground(Color.white);
       b1.setBounds(150,80,150,20);
        imimage.add(b1);
       
       b2=new JRadioButton("Fixed Deposit");
       b2.setFont(new Font("Raleway",Font.BOLD,16));
       b2.setBackground(Color.white);
       b2.setBounds(500,80,300,20);
        imimage.add(b2);
       
       b3=new JRadioButton("Current Account");
       b3.setFont(new Font("Raleway",Font.BOLD,16));
       b3.setBackground(Color.white);
       b3.setBounds(150,120,300,20);
        imimage.add(b3);
       
       b4=new JRadioButton("Recurring Deposite Account");
       b4.setFont(new Font("Raleway",Font.BOLD,16));
       b4.setBackground(Color.white);
       b4.setBounds(500,120,300,20);
        imimage.add(b4);
       
       
       ButtonGroup grp1 = new ButtonGroup();
       grp1.add(b1);
       grp1.add(b2);
       grp1.add(b3);
       grp1.add(b4);
       
       
       // Demonstration card number and pin 
        card=new JLabel("Card Number");
       card.setFont(new Font("Raleway",Font.BOLD,18));
       card.setBounds(100,180,200,40);
        imimage.add(card);
       
        number=new JLabel("XXXX-XXXX-XXXX-0001");
       number.setFont(new Font("Raleway",Font.PLAIN,18));
       number.setBounds(350,180,250,40);
        imimage.add(number);
       
        ncard=new JLabel(" (Your 16 digit Card Number)");
       ncard.setFont(new Font("Raleway",Font.BOLD,12));
       ncard.setBounds(100,200,200,40);
        imimage.add(ncard);
       
       
       
        pin=new JLabel("PIN");
       pin.setFont(new Font("Raleway",Font.BOLD,18));
       pin.setBounds(100,230,200,40);
        imimage.add(pin);
       
        pnumber=new JLabel("XXXX");
       pnumber.setFont(new Font("Raleway",Font.PLAIN,18));
       pnumber.setBounds(350,230,250,40);
        imimage.add(pnumber);
       
         npin=new JLabel(" (Your 4 digit-PIN NUMBER)");
       npin.setFont(new Font("Raleway",Font.BOLD,12));
       npin.setBounds(100,250,200,40);
        imimage.add(npin);
       
       
     service=new JLabel("Services:");
       service.setFont(new Font("Raleway",Font.CENTER_BASELINE,20));
       service.setBounds(100,300,200,40);
        imimage.add(service);
      
       c1=new JCheckBox("ATM CARD");
       c1.setBackground(Color.WHITE);
       c1.setFont(new Font("Raleway",Font.BOLD,16));
       c1.setBounds(100,340,200,20);
        imimage.add(c1);
       
      c2=new JCheckBox("Internet Banking");
       c2.setBackground(Color.WHITE);
       c2.setFont(new Font("Raleway",Font.BOLD,16));
       c2.setBounds(400,340,200,22);
        imimage.add(c2);
       
       c3=new JCheckBox("Mobile Banking");
       c3.setBackground(Color.WHITE);
       c3.setFont(new Font("Raleway",Font.BOLD,16));
       c3.setBounds(100,380,200,22);
        imimage.add(c3);
       
       
       c4=new JCheckBox("Email& SMS Alerts");
       c4.setBackground(Color.WHITE);
       c4.setFont(new Font("Raleway",Font.BOLD,16));
       c4.setBounds(400,380,200,20);
        imimage.add(c4);
       
       c5=new JCheckBox("Cheque Book");
       c5.setBackground(Color.WHITE);
       c5.setFont(new Font("Raleway",Font.BOLD,16));
       c5.setBounds(100,420,200,20);
        imimage.add(c5);
       
       c6=new JCheckBox("E-Statement");
       c6.setBackground(Color.WHITE);
       c6.setFont(new Font("Raleway",Font.BOLD,16));
       c6.setBounds(400,420,200,20);
        imimage.add(c6);
       
       
       c7=new JCheckBox("I Here By Declare All The Above Information Are Correct And Updated ");
       c7.setBackground(Color.WHITE);
       c7.setFont(new Font("Raleway",Font.BOLD,15));
      c7.setForeground(Color.red);
       c7.setBounds(120,480,580,20);
        imimage.add(c7);
       
       
       submit=new JButton("SUBMIT");
       submit.setForeground(Color.WHITE);
       submit.setBackground(Color.black);
       submit.setFont(new Font("Raleway",Font.BOLD,18));
       submit.setBounds(150,560,150,40);
       submit.addActionListener(this);
       imimage.add(submit);
        
       
        cancel=new JButton("CANCEL");
       cancel.setForeground(Color.WHITE);
       cancel.setBackground(Color.black);
       cancel.setFont(new Font("Raleway",Font.BOLD,18));
       cancel.setBounds(500,560,150,40);
       cancel.addActionListener(this);
       imimage.add(cancel);
        
        
        
        
       getContentPane().setBackground(Color.WHITE);
       setSize(850,820);
       setLocation(350,0);
       setVisible(true);
   
   } 
   
   
   
   
    
    
    
    
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==submit){
            String accounttype="";
            if(b1.isSelected()){
               accounttype="saving Account"; 
            }
            else if(b2.isSelected()){
                accounttype="Fixed Deposit";
            }
            else if(b3.isSelected()){
                accounttype="Current Account";
            }
            else if(b4.isSelected()){
                accounttype="Reccuring Deposite Account";
                
            }
            
            Random ran=new Random();
            String cardnumber =""+Math.abs((ran.nextLong() %90000000L)+5040936000000000L);
            
            String pinnumber = "" + Math.abs((ran.nextLong()% 9000L)+1000L);
            
            String facility ="";
            if(c1.isSelected()){
                facility = facility + "ATM Card";
                
            }
            else if(c2.isSelected()){
                facility=facility + "Internet Banking";
                
            }
            else if(c3.isSelected()){
                facility=facility+"Mobile Banking";
            }
             else if(c4.isSelected()){
                facility=facility+"Email&SMS Alerts";
            }
            
             else if(c4.isSelected()){
                facility=facility+"Cheque Book";
            }
            
           else if(c5.isSelected()){
                facility=facility+"E-Statement";
            }
            
            String mark="";
            if(c7.isSelected()){
                mark=mark+"I Here By Declare All The Above Information Are Correct And Updated";
            }
            
            
            try{
                if(accounttype.equals("")){
                    JOptionPane.showMessageDialog(null,"Please Select Account Type");
                    
                }else if(mark.equals("")){
                    JOptionPane.showMessageDialog(null,"Kindly Agree The Above Terms and Conditions  ");
                }
                else{
                    Conn conn = new Conn();
                    String query1 = "insert into signupthreee values('"+formno+"','"+name+"','"+accounttype+"','"+cardnumber+"','"+pinnumber+"','"+facility+"')";
                     String query2 = "insert into login values('"+formno+"','"+cardnumber+"','"+pinnumber+"')";
                    conn.s.executeUpdate(query1);
                     conn.s.executeUpdate(query2);
                     
                     
                    JOptionPane.showMessageDialog(null,"Card Number: "+cardnumber+"\n PIN: "+pinnumber);
                    
                     setVisible(false);
                JOptionPane.showMessageDialog(null, "Please deposit the money to start the account" );
                new DepoInitial(pinnumber).setVisible(true);
                    
                    
                }
                
               
                
            }catch(Exception e){
                System.out.println(e);
            }
            
            
            

            
        }else if(ae.getSource()==cancel){
            setVisible(false);
            new Login().setVisible(true);
            
        }
    }
    
    
    
    
    
    public static void main(String args[]){
        new SignupThree("","");
    }
    
}
