
package bank.management.system;




import java.awt.*;
import javax.swing.*;
import java.awt.event.*;


import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;


public class Secondsignup extends JFrame implements ActionListener {
   
     JTextField pantext, adhartext;
        JButton next;
        JRadioButton syes,sno,eyes,eno;
        JComboBox religion,category,education,income,occupation;
        String formno;
        String name;
       
    
    
   Secondsignup(String formno ,String name){
       this.name=name;
       this.formno=formno;
        setLayout(null);  //border layout
        
        
        ImageIcon im1 = new ImageIcon(ClassLoader.getSystemResource("icons/form1.jpg"));
        Image im2=im1.getImage().getScaledInstance(850,800,Image.SCALE_DEFAULT);
        ImageIcon im3=new ImageIcon(im2);
        JLabel imimage= new JLabel(im3);
        imimage.setBounds(0,0,850,800);
        add(imimage);
      
        setTitle("NEW ACCOUNT APPLICATION FORM");
        
        //Application heading code
        
        
        
        
        JLabel adddetail = new JLabel("Additional Details" +"     "+formno );
        adddetail .setFont(new Font("Times new Roman",Font.BOLD,30));
        adddetail .setBounds(255,40,400,30);
        imimage.add(adddetail );
        
        
        
        
        
        
        
        JLabel name1 = new JLabel("Religion" );
        name1 .setFont(new Font("Raleway",Font.BOLD,17));
        name1 .setBounds(95,100,100,30);
        imimage.add(name1 );
        
        
        String valre[] = {"Hindu","Muslim","Christian","Sikh","Jain","Buddhist","Other"};
         religion=new JComboBox(valre);
        religion.setBounds(300,100,400,30);
        religion.setBackground(Color.white);
        imimage.add(religion);
       
        
        
         JLabel fname = new JLabel(" Category" );
        fname .setFont(new Font("Raleway",Font.BOLD,17));
        fname .setBounds(95,140,200,30);
        imimage.add(fname );
        String valca[] = {"General","OBC","SC","ST","Other"};
       category=new JComboBox(valca);
        category.setFont(new Font("Arial",Font.BOLD,14));
        category.setBounds(300,140,400,30);
        category.setBackground(Color.white);
        imimage.add(category);
        
       
        
        
        JLabel dob = new JLabel("Income" );
        dob .setFont(new Font("Raleway",Font.BOLD,17));
        dob .setBounds(95,180,200,30);
        imimage.add(dob );
         String valin[] = {"null","<1,50,000","<2,50,000","<8,00000","upto 1000000"};
        income=new JComboBox(valin);
        income.setBounds(300,180,400,30);
        income.setBackground(Color.white);
        imimage.add(income);
        
        
        
        JLabel gender = new JLabel(" Educational" );
        gender .setFont(new Font("Raleway",Font.BOLD,17));
        gender .setBounds(95,240,200,30);
        imimage.add(gender );
        JLabel email = new JLabel("Qualification" );
        email .setFont(new Font("Raleway",Font.BOLD,17));
        email .setBounds(95,255,200,50);
        imimage.add(email );
        String valed[] = {"Metric-fail","Materic-Pass","Secondary-pass","Graduate","Post-Graduate","Doctrate","other"};
        education=new JComboBox(valed);
        education.setBounds(300,255,400,30);
        education.setBackground(Color.white);
        imimage.add(education);
     
        
       
        JLabel marital = new JLabel(" Occupation" );
        marital .setFont(new Font("Raleway",Font.BOLD,17));
        marital .setBounds(95,320,200,30);
        imimage.add(marital );
        String valocc[] = {"Salaried-Employee","Goverment-Servent","Self-Employed","Bussiness","Student","Retired","Doctrate","other"};
      occupation=new JComboBox(valocc);
       occupation.setBounds(300,320,400,30);
       occupation.setBackground(Color.white);
        imimage.add(occupation);
        
   
        JLabel address = new JLabel(" PAN NO." );
        address .setFont(new Font("Raleway",Font.BOLD,17));
        address .setBounds(95,360,190,30);
        imimage.add(address );
        
        pantext=new  JTextField();
        pantext.setFont(new Font("Arial",Font.BOLD,14));
        pantext.setBounds(300,360,400,30);
        imimage.add(pantext);
        
        
        
        JLabel city = new JLabel(" Adhar No." );
        city .setFont(new Font("Raleway",Font.BOLD,17));
        city .setBounds(95,400,200,30);
        imimage.add(city );
        adhartext=new  JTextField();
        adhartext.setFont(new Font("Arial",Font.BOLD,14));
        adhartext.setBounds(300,400,400,30);
        imimage.add(adhartext);
        
        
        
         JLabel state = new JLabel("Senior citizen " );
        state .setFont(new Font("Raleway",Font.BOLD,17));
        state .setBounds(95,450,200,30);
        imimage.add(state );
        
        syes = new JRadioButton("YES");
        syes.setBounds(300,450,60,30);
        imimage.add(syes);
        syes.setBackground(Color.WHITE);
        
        sno = new JRadioButton("NO");
        sno.setBounds(450,450,100,30);
        imimage.add(sno);
        sno.setBackground(Color.WHITE);
        
        ButtonGroup gp= new ButtonGroup();
        gp.add(syes);
        gp.add(sno);
        
         
        
        
        
        
         JLabel pincode = new JLabel(" Existing Account" );
        pincode .setFont(new Font("Raleway",Font.BOLD,17));
        pincode .setBounds(95,500,200,30);
        imimage.add(pincode );
        
          eyes = new JRadioButton("YES");
        eyes.setBounds(300,500,60,30);
        imimage.add(eyes);
        eyes.setBackground(Color.WHITE);
        
         eno = new JRadioButton("NO");
        eno.setBounds(450,500,100,30);
        imimage.add(eno);
        eno.setBackground(Color.WHITE);
        
        ButtonGroup gpe= new ButtonGroup();
        gpe.add(eyes);
        gpe.add(eno);
        
         
      
        
        
        

        
        
        
        

        next = new JButton("Next Page");
        next.setBackground(Color.black);
        next.setForeground(Color.white);
        next.setFont(new Font("Arial",Font.BOLD,13) );
        next.setBounds(600,560,100,30);
        next.addActionListener(this);
        imimage.add(next);
        
        
        
        
        
        getContentPane().setBackground(Color.WHITE);
        setSize(850,800);
        setLocation(250,5);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
        
        if(ae.getSource()==next){
        
        
        //long convert into string
      
       String sreligion =(String) religion.getSelectedItem();
       // type cast because it return object
       
       
       String scategory =(String) category.getSelectedItem();
       String sincome =(String) income.getSelectedItem();
       String seducation =(String) education.getSelectedItem();
       String soccupation =(String) occupation.getSelectedItem();
       String span=pantext.getText();
        String sadhar=adhartext.getText();
       
        String seniorcitizen=null;
        if(syes.isSelected()){
           seniorcitizen  = "YES";
        }
        else {
               seniorcitizen="NO";
        }
       
        
        
        
        String existingaccount=null;
        if(eyes.isSelected()){
            existingaccount = "YES";}
        else {
                    existingaccount="NO";
        }
        
        
        
        try{
            Conn c=new Conn();
                String query = "insert into signuptwo values('"+formno+"','"+sreligion+"','"+scategory+"','"+sincome+"','"+seducation+"','"+soccupation+"',"
                        + "'"+span+"','"+sadhar+"',"
                        + "'"+seniorcitizen+"','"+existingaccount+"')";
            //by using statement class we can execute the query
            c.s.executeUpdate(query);
            
            setVisible(false);
            new SignupThree(formno,name).setVisible(true);
            
            }
            
        catch(Exception e){
            System.out.println(e);
        }
        }
    }
        
        
       
    
    public static void main(String args[]) {
    new Secondsignup("","");
    }
}
