
package bank.management.system;

import java.awt.*;
import javax.swing.*;
import java.util.*; // for random number to generate
import com.toedter.calendar.JDateChooser;
import java.awt.event.*;


public class Signupone extends JFrame implements ActionListener {
    long random;
    JTextField nametext,ftext,etext,addtext, citytext, statetext,pintext;
    JButton next;
    JRadioButton male,female,other,married,unmarried;
    JDateChooser datec;
    //String regularExpression = "^[a-zA-Z][a-zA-Z0-9_]{6,19}$";
    
    
    
    
    Signupone( ){
       
        setLayout(null);
        String regularExpression = "^[a-zA-Z][a-zA-Z0-9_]{6,19}$";
        
//border layout
           ImageIcon im1 = new ImageIcon(ClassLoader.getSystemResource("icons/form1.jpg"));
        Image im2=im1.getImage().getScaledInstance(850,800,Image.SCALE_DEFAULT);
        ImageIcon im3=new ImageIcon(im2);
        JLabel imimage= new JLabel(im3);
        imimage.setBounds(0,0,850,800);
        add(imimage);




        Random ran=new Random();
         random=Math.abs((ran.nextLong()%9000L)+1000L);
        
        //Application heading code
        JLabel formno = new JLabel("Application Form NO." + random );
        formno.setFont(new Font("Raleway",Font.BOLD,35));
        formno.setBounds(230,20,600,40);
        imimage.add(formno);
        
        
        
        JLabel personaldetail = new JLabel("Personal Details" );
        personaldetail .setFont(new Font("Raleway",Font.BOLD,18));
        personaldetail .setBounds(290,65,400,30);
        imimage.add(personaldetail );
        
        
        JLabel name = new JLabel("Name" );
        name .setFont(new Font("Times new Roman",Font.BOLD,20));
        name .setBounds(95,100,100,30);
        imimage.add(name );
        
         nametext=new  JTextField();
        nametext.setFont(new Font("Arial",Font.BOLD,14));
        nametext.setBounds(300,100,400,30);
        imimage.add(nametext);
        
        
         JLabel fname = new JLabel(" Father Name" );
        fname .setFont(new Font("Times new Roman",Font.BOLD,20));
        fname .setBounds(95,140,200,30);
        imimage.add(fname );
        
         ftext=new  JTextField();
        ftext.setFont(new Font("Arial",Font.BOLD,14));
        ftext.setBounds(300,140,400,30);
        imimage.add(ftext);
        
        
        JLabel dob = new JLabel(" Date-Of-Birth" );
        dob .setFont(new Font("Times new Roman",Font.BOLD,20));
        dob .setBounds(95,180,200,30);
        imimage.add(dob );
        
        datec=new   JDateChooser();
       datec.setBounds(300,180,400,30);
       datec.setForeground(Color.black);
       imimage.add(datec); 
        
        JLabel gender = new JLabel(" Gender" );
        gender .setFont(new Font("Times new Roman",Font.BOLD,20));
        gender .setBounds(95,240,200,30);
        imimage.add(gender );
        
         male = new JRadioButton("Male");
         male.setFont(new Font("Raleway",Font.PLAIN,16));
        male.setBounds(300,240,66,30);
        imimage.add(male);
        male.setBackground(Color.WHITE);
         female = new JRadioButton("Female");
        female.setBounds(450,240,100,30);
        female.setFont(new Font("Raleway",Font.PLAIN,16));
        imimage.add(female);
        female.setBackground(Color.WHITE);
        
        ButtonGroup gp= new ButtonGroup();
        gp.add(male);
        gp.add(female);
        
        
        
        
        JLabel email = new JLabel(" Email" );
        email .setFont(new Font("Times new Roman",Font.BOLD,20));
        email .setBounds(95,280,200,30);
        imimage.add(email );
        
       etext=new  JTextField();
        etext.setFont(new Font("Arial",Font.BOLD,14));
        etext.setBounds(300,280,400,30);
        imimage.add(etext);
        
       
        JLabel marital = new JLabel(" Marital Status" );
        marital .setFont(new Font("Times new Roman",Font.BOLD,20));
       
        marital .setBounds(95,320,200,30);
        imimage.add(marital );
        
        married = new JRadioButton("Married");
        married.setBounds(300,320,100,30);
         married .setFont(new Font("Raleway",Font.PLAIN,16));
        imimage.add(married);
        married.setBackground(Color.WHITE);
        
         unmarried = new JRadioButton("Unmarried");
        unmarried.setBounds(450,320,120,30);
        unmarried .setFont(new Font("Raleway",Font.PLAIN,16));
        imimage.add(unmarried);
        unmarried.setBackground(Color.WHITE);
        
        
         other = new JRadioButton("Other");
         other .setFont(new Font("Raleway",Font.PLAIN,16));
        other.setBounds(630,320,80,30);
        imimage.add(other);
        other.setBackground(Color.WHITE);
        
        
        
        ButtonGroup gp1= new ButtonGroup();
        gp1.add(married);
        gp1.add(unmarried);
        gp1.add(other);
        
        
        
        
        JLabel address = new JLabel(" Address" );
        address .setFont(new Font("Times new Roman",Font.BOLD,20));
        address .setBounds(95,360,190,30);
        imimage.add(address );
        
         addtext=new  JTextField();
        addtext.setFont(new Font("Arial",Font.BOLD,14));
        addtext.setBounds(300,360,400,30);
        imimage.add(addtext);
        
        
        
        JLabel city = new JLabel("City " );
        city .setFont(new Font("Times new Roman",Font.BOLD,20));
        city .setBounds(95,400,200,30);
        imimage.add(city );
        
         
         citytext=new  JTextField();
        citytext.setFont(new Font("Arial",Font.BOLD,14));
        citytext.setBounds(300,400,400,30);
        imimage.add(citytext);
        
        
        
         JLabel state = new JLabel("State " );
        state .setFont(new Font("Times new Roman",Font.BOLD,20));
        state .setBounds(95,450,200,30);
        imimage.add(state );
        
         
         statetext=new  JTextField();
        statetext.setFont(new Font("Arial",Font.BOLD,12));
        statetext.setBounds(300,450,400,30);
        imimage.add(statetext);
        
        
        
         JLabel pincode = new JLabel("Pincode " );
        pincode .setFont(new Font("Times new Roman",Font.BOLD,20));
        pincode .setBounds(95,500,200,30);
        imimage.add(pincode );
        
         
       pintext=new  JTextField();
        pintext.setFont(new Font("Arial",Font.BOLD,14));
        pintext.setBounds(300,500,400,30);
        imimage.add(pintext);
        
        
        next = new JButton("Next Page");
        next.setBackground(Color.black);
        next.setForeground(Color.white);
        next.setFont(new Font("Arial",Font.BOLD,16) );
        next.setBounds(600,560,120,30);
        next.addActionListener(this);
        imimage.add(next);
        
        
        getContentPane().setBackground(Color.WHITE);
        setSize(850,800);
        setLocation(250,5);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
        String formno = ""+random;//long convert into string
        String name = nametext.getText();
        String fname = ftext.getText();
        String dob=((JTextField)datec.getDateEditor().getUiComponent()).getText();
        String gender=null;
        if(male.isSelected()){
            gender = "Male";}
        else if(female.isSelected()){
                    gender="Female";
        }
        
        String email=etext.getText();
        String marital=null; // because only single button will selected
        if(married.isSelected()){
           marital = "Married";
        }
        else if(unmarried.isSelected()){
            marital="Unmarried";
            
        }
        else {
            marital="other";
        }
        
        String address=addtext.getText();
        String city=citytext.getText();
        String state=statetext.getText();
        String pincode = pintext.getText();
        
       
        try{
             char[] ch = name.toCharArray();
        
        for (char c : ch) {
         if(!Character.isLetter(c)) {
             JOptionPane.showMessageDialog(null,"Invalid Expression");
            
         }
         else if(name.equals("")){
              JOptionPane.showMessageDialog(null,"Enter your name");
             
         }
      }
        
//        char[]ch1=fname.toCharArray();
//        for(char k:ch1){
//            if(!Character.isLetter(k)) 
//            {
//             JOptionPane.showMessageDialog(null,"Invalid Expression");
//            
//         }
//      }
//            
       
        if(name.equals("")  ){
                 JOptionPane.showMessageDialog(null,"Please Enter Your  name");
                
            }
           
            else  if(email.equals("")){
                 JOptionPane.showMessageDialog(null,"Please Enter Your email");
                
            }
            else if(address.equals("")){
                JOptionPane.showMessageDialog(null,"Please Enter Your Address");
                
            }
            else{
                Conn c=new Conn();
                String query = "insert into signuppageee values('"+formno+"','"+name+"','"+fname+"','"+dob+"','"+gender+"','"+email+"',"
                        + "'"+marital+"','"+address+"',"
                        + "'"+city+"','"+state+"','"+pincode+"')";
            //by using statement class we can execute the query
            c.s.executeUpdate(query);
            setVisible(false);
            new Secondsignup(formno,name).setVisible(true); // for go to second page
            
            
            }
            
        }catch(Exception e){
            System.out.println(e);
        }
    }
    public static void main(String args[]) {
    new Signupone();
   
    
    }
}
