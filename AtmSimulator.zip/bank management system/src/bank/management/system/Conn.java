
package bank.management.system;
import java.sql.*;


public class Conn {
    Connection c;
    Statement s;
    
   //step 1 Create connection
    
    
    public Conn(){
        try{     // my sql is external entity exception chaces is more
          
            //create connection
            c=DriverManager.getConnection("jdbc:mysql:///mybank","root","Manali@17");
            s=c.createStatement();
            
            
        } catch(Exception e){
            System.out.println(e);
        }
    }
    
}
