
package bank.management.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;


public class Login extends JFrame implements ActionListener{
    JButton login,signup,clear;                   // button globally define so that it can be used any where
    JTextField cardtext;
    JPasswordField pintext;
    Login(){
        
        
        
        
        
        
        setTitle("Automatic Teller Machine");
        setLayout(null);
        
        
        ImageIcon im1 = new ImageIcon(ClassLoader.getSystemResource("icons/login.jpg"));
        Image im2=im1.getImage().getScaledInstance(800,600,Image.SCALE_DEFAULT);
        ImageIcon im3=new ImageIcon(im2);
        JLabel imimage= new JLabel(im3);
        imimage.setBounds(0,0,800,600);
        add(imimage);
        
        
        
        
        
        
        
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/logo.jpg"));
        
        Image i2 = i1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel label = new JLabel (i3);
        label.setBounds(70,10,100,100);
        imimage.add(label);
        
        //writing content to the frame
        
        JLabel text = new JLabel("WELCOME TO OUR ATM");
        text.setFont(new Font("Algerian",Font.BOLD,45));
        text.setForeground(Color.WHITE);
        text.setBounds(200,40,500,40);
        imimage.add(text);
        
        //For card 
        JLabel cardno = new JLabel("Card No:");
        cardno.setFont(new Font("Times new Roman",Font.BOLD,30));
        cardno.setBounds(100,130,180,30);
        imimage.add(cardno);
         cardtext = new JTextField();
        cardtext.setBounds(250,130,330,30);
        cardtext.setBackground(Color.WHITE);
         cardtext.setFont(new Font("Arial",Font.BOLD,16));
        imimage.add(cardtext);
       
        //For pin no
        JLabel pinno = new JLabel(" PIN: ");
        pinno.setFont(new Font("Times new Roman",Font.BOLD,30));
        pinno.setBounds(100,200,500,40);
        imimage.add(pinno);
        pintext = new JPasswordField();
        pintext.setBounds(250,200,330,30);
        pintext.setFont(new Font("Arial",Font.BOLD,16));
        imimage.add(pintext);
        
        //All Button Work is done Here
        
        login = new JButton("SIGN IN");
        login.setBounds(250,270,100,30);
        login.setForeground(Color.WHITE);
        login.setBackground(Color.black);
        login.setFont(new Font("Times new Roman",Font.BOLD,15));
        login.addActionListener(this);
        imimage.add(login);
        
        
    
        
        
        clear = new JButton("CLEAR");
        clear.setBounds(480,270,100,30);
        clear.setForeground(Color.WHITE);
        clear.setBackground(Color.black);
        clear.setFont(new Font("Times new Roman",Font.BOLD,15));
        clear.addActionListener(this);
        imimage.add(clear);
        
        
        signup = new JButton("SIGNUP");
        signup.setBounds(340,330,150 ,30);
        signup.setForeground(Color.WHITE);
        signup.setBackground(Color.black);
        signup.setFont(new Font("Times new Roman",Font.BOLD,15));
        signup.addActionListener(this);
        imimage.add(signup);
        
        
        
        
//        getContentPane().setBackground(Color.pink);
        setSize(800,480);
        setVisible(true);
        setLocation(300,100);//left to top
        
    }
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()== clear){
            
            cardtext.setText("");
            pintext.setText("");
        
        }
        else if(ae.getSource()==login){
            
            
            
            try{
            Conn conn = new Conn();
            String cardnumber=cardtext.getText();
            String pinnumber=pintext.getText();
            String query1 = "select * from login where cardnumber ='"+cardnumber+"' and pin ='"+ pinnumber+"'";
               ResultSet rs= conn.s.executeQuery(query1);
               if(rs.next()){
                   setVisible(false);
                   new Transaction(pinnumber).setVisible(true);
               }
               else{
                   JOptionPane.showMessageDialog(null,"Invalid Card NO. or Pin NO." );
               }
                
            }catch(Exception e){
                System.out.println(e);
            }
            
            
            
        
        
        
        }
        else if(ae.getSource()==signup){
                setVisible(false);
            new Signupone().setVisible(true);
            
        }

    }
    public static void main(String args[]) {
        new Login();//object create
       
    }
}
