
package bank.management.system;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import javax.swing.*;
import java.awt.event.*;

public class Pinchange extends JFrame implements ActionListener {
    JButton change,back;
    JPasswordField repin,pin;
    String pinnumber; 
    
    Pinchange(String pinnumber){
      this.pinnumber=pinnumber;
        
         setLayout(null);
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/atm.jpg"));
        Image i2=i1.getImage().getScaledInstance(800,700,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel image= new JLabel(i3);
        image.setBounds(0,0,800,700);
        add(image);
        
        
        JLabel text1 = new JLabel("Are you Sure to Change Your Pin");
        text1.setBounds(150,210,500,80);
        text1.setForeground(Color.YELLOW);
        text1.setFont(new Font("Bodoni MT Black",Font.BOLD,16));
        image.add(text1);
        
        
        JLabel pintext = new JLabel("NEW PIN :");
        pintext.setBounds(145,250,300,80);
        pintext.setForeground(Color.WHITE);
        pintext.setFont(new Font("Times new Roman",Font.BOLD,14));
        image.add(pintext);
        
        pin=new JPasswordField();
        pin.setFont(new Font("Raleway",Font.BOLD,22));
        pin.setBounds(250,280,200,20);
        image.add(pin);
        
        
        
        JLabel repintext = new JLabel("CONFIRM PIN :");
        repintext.setBounds(140,280,300,80);
        repintext.setForeground(Color.WHITE);
        repintext.setFont(new Font("Times new Roman",Font.BOLD,14));
        image.add(repintext);
        
         repin=new JPasswordField();
        repin.setFont(new Font("Raleway",Font.BOLD,22));
        repin.setBounds(250,315,200,20);
        image.add(repin);
        
        
        change=new JButton("CHANGE");
        change.setBounds(160,360,110,20);
        change.addActionListener(this);
        image.add(change);
        
        back=new JButton("BACK");
        back.setBounds(320,360,110,20);
        back.addActionListener(this);
        image.add(back);
        
        
        
        
        setSize(800,670);
        setLocation(300,0);
        setUndecorated(true);
        setVisible(true);
    }
        
        public void actionPerformed(ActionEvent ae){
            if(ae.getSource()==change){
            try{
                String npin=pin.getText();
                int size1=npin.length();
                String rpin=repin.getText();
                
                if(!npin.equals(rpin)){
                    JOptionPane.showMessageDialog(null,"Pin doesn't match");
                    return;
                }
                if(npin.equals("")){
                    JOptionPane.showMessageDialog(null,"Please fill the new pin");
                return ;
                }
                else if(rpin.equals("")){
                    JOptionPane.showMessageDialog(null,"Please fill the pin to confirm");
                    return;
                    
                }
                else if(size1!=4){
                    JOptionPane.showMessageDialog(null, "Please enter 4-Digit Pin ");
                    return;
                }
                
                Conn conn = new Conn();
                String query1="update amount set pin ='"+npin+"' where pin='"+pinnumber+"'";
                String query2="update login set pin ='"+npin+"' where pin='"+pinnumber+"'";
                String query3="update signupthree set pin ='"+npin+"' where pin='"+pinnumber+"'";
                String query4="update fast_cash set pin ='"+npin+"' where pin='"+pinnumber+"'";
                conn.s.executeUpdate(query1);
                 conn.s.executeUpdate(query2);
                  conn.s.executeUpdate(query3);
                   conn.s.executeUpdate(query4);
                   JOptionPane.showMessageDialog(null,"Pin Change Successfully");
                   setVisible(false);
                   new Transaction(npin).setVisible(true);
            }
            
                
                
            
        catch(Exception e){
            System.out.println(e);
        }
            }
            else{
                setVisible(false);
                new Transaction(pinnumber).setVisible(true);
                    
                    }
            
        
        
        
    }
    public static void main(String args[]){
        new Pinchange("").setVisible(true);
    }
    
}
