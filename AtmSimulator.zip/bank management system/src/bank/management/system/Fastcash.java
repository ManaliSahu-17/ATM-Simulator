
package bank.management.system;




import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;   // compiler is confuse where date can selected 
import java.util.Date;




public class Fastcash extends JFrame implements ActionListener{
   
    JButton deposit,withdrawl,pinchange,fastcash,balanceenquiry,exit,ministatement;

    String pinnumber;
    
  Fastcash (String pinnumber){
        this.pinnumber=pinnumber;
        
        setLayout(null);
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/atm.jpg"));
        Image i2=i1.getImage().getScaledInstance(800,700,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel image= new JLabel(i3);
        image.setBounds(0,0,800,700);
        add(image);
        
        
        
        
        
        
        
        
         JLabel text1 = new JLabel("Select Withdrawl Amount");
        text1.setBounds(180,210,500,80);
        text1.setForeground(Color.YELLOW);
        text1.setFont(new Font("Raleway",Font.BOLD,20));
        image.add(text1);
        
        
        
        
        
        deposit=new JButton("Rs 100");
        deposit.setBounds(140,325,140,22);
        deposit.addActionListener(this);
        image.add(deposit);
        
         withdrawl=new JButton("Rs 500");
        withdrawl.setBounds(310,325,150,22);
        withdrawl.addActionListener(this);
        image.add(withdrawl);
        
        
        fastcash = new JButton("Rs 1000");
        fastcash.setBounds(140,353,140,22);
        fastcash.addActionListener(this);
        image.add(fastcash);
        
        
        
        
         ministatement = new JButton("Rs 2000");
        ministatement.setBounds(310,353,150,22);
        ministatement.addActionListener(this);
        image.add(ministatement);
        
        
        
         pinchange = new JButton("Rs 5000");
        pinchange.setBounds(140,380,140,22);
        pinchange.addActionListener(this);
        image.add(pinchange);
        
         balanceenquiry = new JButton("Rs 10000");
       balanceenquiry.setBounds(305,380,156,22);
       balanceenquiry.addActionListener(this);
        image.add(balanceenquiry);
        
         exit = new JButton("Back");
      exit.setBounds(310,408,150,20);
     exit.addActionListener(this);
        image.add(exit);
        
        
       
        
        setSize(800,670);
        setLocation(300,0);
        //setUndecorated(true);
        setVisible(true);
        
    }
    public void actionPerformed(ActionEvent ae){  // override the method
        if(ae.getSource()== exit){
           setVisible(false);
           new Transaction(pinnumber).setVisible(true);
           
        }
        else {
            String amount =((JButton)ae.getSource()).getText().substring(3); // from third caracter we have take the amount eg RS 300
            Conn c = new Conn();
            try{
                
                // to check the balance in the account
                ResultSet rs = c.s.executeQuery("select * from amount where pin ='"+pinnumber+"'");
                int balance =0;
                while(rs.next()){
                    if(rs.getString("type").equals("deposit")){
                       balance += Integer.parseInt(rs.getString("amount")); 
                    }
                    else{
                        balance -=Integer.parseInt(rs.getString("amount"));
                    }
                }
                
                if(ae.getSource()!=exit && balance <Integer.parseInt(amount)){
                    JOptionPane.showMessageDialog(null,"Insufficient Balance");
                    return;
                }
                
                Date date = new Date();
                String query = "insert into fast_cash values('"+pinnumber+"','"+date+"','withdrawl','"+amount+"')";
                String query1 = "insert into amount values('"+pinnumber+"','"+date+"','withdrawl','"+amount+"')";
                c.s.executeUpdate(query);
                c.s.executeUpdate(query1);
                JOptionPane.showMessageDialog(null,"Rs "+ amount + "Withdrawl Successfully" );
                
                setVisible(false);
                new Transaction(pinnumber).setVisible(true);
                
            }
                catch(Exception e){
                System.out.println(e);
            }
            
            
        }
        
    }
    
    public static void main(String args[]){
        new Fastcash (""); // calling constructor
        
    }
    
}

