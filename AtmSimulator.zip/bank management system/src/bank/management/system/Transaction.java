
package bank.management.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Transaction extends JFrame implements ActionListener{
   
    JButton deposit,withdrawl,pinchange,fastcash,balanceenquiry,exit,ministatement,feedback;

    String pinnumber;
    
    
    Transaction(String pinnumber){
        this.pinnumber=pinnumber;
       
        
        
        
        setLayout(null);
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/atm.jpg"));
        Image i2=i1.getImage().getScaledInstance(800,700,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel image= new JLabel(i3);
        image.setBounds(0,0,800,700);
        add(image);
        
        
        
        
        ImageIcon im1 = new ImageIcon(ClassLoader.getSystemResource("icons/logo.jpg"));
        Image im2=im1.getImage().getScaledInstance(35,35,Image.SCALE_DEFAULT);
        ImageIcon im3=new ImageIcon(im2);
        JLabel imimage= new JLabel(im3);
        imimage.setBounds(190,238,35,35);
        image.add(imimage);
        
        
        
         JLabel text1 = new JLabel("Welcome");
        text1.setBounds(260,210,500,80);
        text1.setForeground(Color.ORANGE);
        text1.setFont(new Font("Cooper Black",Font.BOLD,30));
        image.add(text1);
        
        
        JLabel text = new JLabel("PLEASE SELECT YOUR TRANSACTION");
        text.setBounds(160,270,600,50);
        text.setForeground(Color.green);
        text.setFont(new Font("ALGERIAN",Font.BOLD,15));
        image.add(text);
        
        
        deposit=new JButton("CASH DEPOSIT");
        deposit.setBounds(140,325,140,22);
        deposit.addActionListener(this);
        image.add(deposit);
        
         withdrawl=new JButton("CASH WITHDRAWL");
        withdrawl.setBounds(310,325,150,22);
        withdrawl.addActionListener(this);
        image.add(withdrawl);
        
        
        fastcash = new JButton("FAST CASH");
        fastcash.setBounds(140,353,140,22);
        fastcash.addActionListener(this);
        image.add(fastcash);
        
        
        
        
         ministatement = new JButton("MINI STATEMENT");
        ministatement.setBounds(310,353,150,22);
        ministatement.addActionListener(this);
        image.add(ministatement);
        
        
        
         pinchange = new JButton("PIN CHANGE");
        pinchange.setBounds(140,380,140,22);
        pinchange.addActionListener(this);
        image.add(pinchange);
        
         balanceenquiry = new JButton("BALANCE ENQUERY");
       balanceenquiry.setBounds(305,380,156,22);
       balanceenquiry.addActionListener(this);
        image.add(balanceenquiry);
        
         exit = new JButton("EXIT");
      exit.setBounds(310,408,150,20);
     exit.addActionListener(this);
        image.add(exit);
        
         feedback = new JButton("FEEDBACK");
      feedback.setBounds(140,409,140,20);
     feedback.addActionListener(this);
        image.add(feedback);
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        setSize(800,670);
        setLocation(300,0);
        setUndecorated(true);
        setVisible(true);
        
    }
    public void actionPerformed(ActionEvent ae){  // override the method
        if(ae.getSource()== exit){
            System.exit(0);
        }
        else if(ae.getSource()==deposit){
            setVisible(false);
            new Deposit(pinnumber).setVisible(true);
        }
        else if(ae.getSource()==withdrawl){
            setVisible(false);
            new Withdrawl(pinnumber).setVisible(true);
        }
        else if(ae.getSource()==fastcash){
            setVisible(false);
            new Fastcash(pinnumber).setVisible(true);
            
        }
        else if(ae.getSource()==pinchange){
            setVisible(false);
            new Pinchange(pinnumber).setVisible(true);
        }
        else if(ae.getSource()==balanceenquiry){
            setVisible(false);
            new Balance(pinnumber).setVisible(true);
        }
        
        else if(ae.getSource()==ministatement){
            setVisible(false);
            new Ministatement2(pinnumber).setVisible(true);
        }
        else if(ae.getSource()==feedback){
            setVisible(false);
            new Feedback(pinnumber).setVisible(true);
        }
        
    }
    
    public static void main(String args[]){
        new Transaction(""); // calling constructor
        
    }
    
}
