
package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;


public class Feedback extends JFrame implements ActionListener  {
    
    JTextField nametext3,nametext4;
    JRadioButton b1,b2,b3,b4;
    JCheckBox c1,c2,c3,c4;
    JButton next;
    String pinnumber;
    Feedback(String pinnumber){
        this.pinnumber=pinnumber;
        
        setLayout(null);
        
        ImageIcon im1 = new ImageIcon(ClassLoader.getSystemResource("icons/logo.jpg"));
        Image im2=im1.getImage().getScaledInstance(60,60,Image.SCALE_DEFAULT);
        ImageIcon im3=new ImageIcon(im2);
        JLabel imimage= new JLabel(im3);
        imimage.setBounds(10,10,40,40);
        add(imimage);
        
        
        
        
       JLabel text=new JLabel("Bartiya Janta Bank");
       text.setBounds(50,20,200,30);
       text.setFont(new Font("Raleway",Font.BOLD,16));
      text.setForeground(Color.green);
       add(text);
       
       
       JLabel text1=new JLabel("Customer Feedback Form---Accessible Formats");
       text1.setBounds(220,15,500,40);
       text1.setFont(new Font("Arial round",Font.BOLD,22));
      text1.setForeground(Color.black);
       add(text1);
       
       
       JLabel text2=new JLabel("Thank you for visiting our Atm.We value all of our customers and strive to meet everyone's needs");
       text2.setBounds(150,60,900,30);
       text2.setFont(new Font("Times new Roman",Font.BOLD,14));
      text2.setForeground(Color.blue);
       add(text2);
        
       
       JLabel text3=new JLabel("1) Nature of Your Visit:");
       text3.setBounds(50,93,400,30);
       text3.setFont(new Font("Times new Roman",Font.BOLD,15));
      text3.setForeground(Color.black);
       add(text3);
       
       nametext3=new  JTextField();
        nametext3.setFont(new Font("Arial",Font.BOLD,14));
        nametext3.setBounds(220,96,400,25);
       add(nametext3);
       
       
       JLabel text4=new JLabel("2) Did we  respond to your service needs today?");
       text4.setBounds(50,130,400,30);
       text4.setFont(new Font("Times new Roman",Font.BOLD,15));
      text4.setForeground(Color.black);
       add(text4);
       
       b1=new JRadioButton("YES");
       b1.setFont(new Font("Times new Roman",Font.BOLD,14));
       b1.setBackground(Color.white);
       b1.setBounds(70,155,70,25);
       add(b1);
       
       b2=new JRadioButton("NO");
       b2.setFont(new Font("Times new Roman",Font.BOLD,14));
       b2.setBackground(Color.white);
       b2.setBounds(160,155,70,25);
       add(b2);
       
       
        JLabel text5=new JLabel("3) Did you have any problem while acessing our products and services?");
       text5.setBounds(50,190,700,30);
       text5.setFont(new Font("Times new Roman",Font.BOLD,15));
      text5.setForeground(Color.black);
       add(text5);
       
       
       b3=new JRadioButton("YES");
       b3.setFont(new Font("Times new Roman",Font.BOLD,14));
       b3.setBackground(Color.white);
       b3.setBounds(70,220,70,25);
       add(b3);
       
       b4=new JRadioButton("NO");
       b4.setFont(new Font("Times new Roman",Font.BOLD,14));
       b4.setBackground(Color.white);
       b4.setBounds(160,220,70,25);
       add(b4);
       
       
       
       ButtonGroup grp1 = new ButtonGroup();
       grp1.add(b1);
       grp1.add(b2);
       
       ButtonGroup grp2 = new ButtonGroup();
       grp2.add(b3);
       grp2.add(b4);
       
       
       
       
       JLabel text6=new JLabel("4) What are the features most important to you ?");
       text6.setBounds(50,250,700,30);
       text6.setFont(new Font("Times new Roman",Font.BOLD,15));
      text6.setForeground(Color.black);
       add(text6);
       
       c1=new JCheckBox("Custom and quick responses");
       c1.setBackground(Color.WHITE);
       c1.setFont(new Font("Times new Roman",Font.BOLD,14));
       c1.setBounds(60,280,250,20);
       add(c1);
       
      c2=new JCheckBox("Expanded functionality");
       c2.setBackground(Color.WHITE);
       c2.setFont(new Font("Times New Roman",Font.BOLD,14));
       c2.setBounds(350,280,250,22);
       add(c2);
       
       c3=new JCheckBox("Easy to navigate");
       c3.setBackground(Color.WHITE);
       c3.setFont(new Font("Times new Roman",Font.BOLD,14));
       c3.setBounds(60,305,250,22);
       add(c3);
       
       c4=new JCheckBox("Easy to use");
       c4.setBackground(Color.WHITE);
       c4.setFont(new Font("Times new Roman",Font.BOLD,14));
       c4.setBounds(350,305,200,22);
       add(c4);
       
       
        JLabel text7=new JLabel("5) How can we improve our service any suggestion Please");
       text7.setBounds(60,340,700,30);
       text7.setFont(new Font("Times new Roman",Font.BOLD,15));
       text7.setForeground(Color.black);
       add(text7);

       nametext4 = new  JTextField();
       nametext4.setFont(new Font("Arial",Font.BOLD,14));
       nametext4.setBounds(80,370,400,25);
       add(nametext4);
       
       
       
        next = new JButton("SUBMIT");
        next.setBackground(Color.black);
        next.setForeground(Color.white);
        next.setFont(new Font("Arial",Font.BOLD,16) );
        next.setBounds(710,600,100,30);
        next.addActionListener(this);
        add(next);
        
        
        
        
        JLabel text9=new JLabel("Contact Us !!");
       text9.setBounds(40,393,200,40);
       text9.setFont(new Font("Times new Roman",Font.BOLD,25));
       text9.setForeground(Color.red);
      
       add(text9);
        
       
        
        ImageIcon im4 = new ImageIcon(ClassLoader.getSystemResource("icons/manali3.jpg"));
        Image im5=im4.getImage().getScaledInstance(175,170,Image.SCALE_DEFAULT);
        ImageIcon im6=new ImageIcon(im5);
        JLabel im= new JLabel(im6);
        im.setBounds(50,437,140,145);
        add(im);
        JLabel text8=new JLabel("Manali Sahu");
       text8.setBounds(70,583,200,20);
       text8.setFont(new Font("Times new Roman",Font.BOLD,16));
       text8.setForeground(Color.black);
       add(text8);
       
       
       JLabel role3=new JLabel( "Role : Developer");
       role3.setBounds(70,600,350,20);
       role3.setForeground(Color.red);
       role3.setFont(new Font("Times new Roman",Font.BOLD,15));
       
       add(role3);
        
       JLabel email3=new JLabel( "manali.sahu_cs20@gla.ac.in");
       email3.setBounds(40,620,350,20);
       email3.setFont(new Font("Times new Roman",Font.BOLD,13));
       email3.setForeground(Color.blue);
       add(email3);
        
        
        
        
      ImageIcon im7 = new ImageIcon(ClassLoader.getSystemResource("icons/kartikey.jpg"));
      Image im8=im7.getImage().getScaledInstance(160,160,Image.SCALE_DEFAULT);
      ImageIcon im9=new ImageIcon(im8);
      JLabel imm1= new JLabel(im9);
      imm1.setBounds(250,437,135,135);
      add(imm1);
        
        JLabel text10=new JLabel( "Kartikey Srivastava");
       text10.setBounds(250,579,200,20);
       text10.setFont(new Font("Times new Roman",Font.BOLD,16));
       text10.setForeground(Color.black);
       add(text10);
       
       
       JLabel role=new JLabel( "Role : Developer");
       role.setBounds(250,599,350,20);
       role.setForeground(Color.red);
       role.setFont(new Font("Times new Roman",Font.BOLD,15));
       
       add(role);
        
       JLabel email=new JLabel( "kartikey.srivastava_cs20@gla.ac.in");
       email.setBounds(230,620,350,20);
       email.setFont(new Font("Times new Roman",Font.BOLD,13));
       email.setForeground(Color.blue);
       add(email);
        
        ImageIcon im10 = new ImageIcon(ClassLoader.getSystemResource("icons/khushijpg.jpg"));
        Image im11=im10.getImage().getScaledInstance(190,170,Image.SCALE_DEFAULT);
        ImageIcon im12=new ImageIcon(im11);
        JLabel imm2= new JLabel(im12);
        imm2.setBounds(470,430,135,150);
        add(imm2);
        
        JLabel text11=new JLabel( "Khushi Gupta");
       text11.setBounds(490,585,200,20);
       text11.setFont(new Font("Times new Roman",Font.BOLD,16));
       text11.setForeground(Color.black);
       add(text11);
       
       
        JLabel role2=new JLabel( "Role : Developer");
       role2.setBounds(490,602,350,20);
       role2.setForeground(Color.red);
       role2.setFont(new Font("Times new Roman",Font.BOLD,15));
       add(role2);
        
       JLabel email2=new JLabel( " khushi.gupta_cs20@gla.ac.in");
       email2.setBounds(465,620,350,20);
       email2.setFont(new Font("Times new Roman",Font.BOLD,13));
       email2.setForeground(Color.blue);
       add(email2);
       
        
       getContentPane().setBackground(Color.WHITE); 
       setSize(850,820);
       setLocation(350,0);
       setVisible(true);
  }
    
    
    
    
 
     public void actionPerformed(ActionEvent ae){
           if(ae.getSource()==next){
               String name1=nametext3.getText();
              String text7=nametext4.getText();
               
           
              String text4=null;
          if(b1.isSelected()){
              text4="yes";
          }
          else{
              text4="No";
          }
          String text5=null;
          if(b3.isSelected()){
              text5="Yes";
          }
          else{
              text5="No";
          }
          
          
          String facility="";
          if(c1.isSelected()){
              facility=facility+"Custom and quick responses";
          }
          else if(c2.isSelected()){
              facility=facility+"Expanded functionality";
          }
          else if(c3.isSelected()){
              facility=facility+"Easy to navigate";
          }
          else if(c4.isSelected()){
              facility=facility+"Easy to use";
          }
          
          if(name1.equals("")){
                  JOptionPane.showMessageDialog(null,"Please fill the purpose of your visit");
              }
          else{
              try{
              
              
                      Conn conn = new Conn();
              String  query="insert into feedback2 values('"+pinnumber+"','"+name1+"','"+text4+"','"+facility+"','"+text7+"')";
              conn.s.executeUpdate(query);
                   setVisible(false);
                   new Transaction(pinnumber).setVisible(true);
              }
          
          catch(Exception e){
              System.out.println(e);
              
          }
              
        
      }
              
          
          
      }
      }
          
      
          
      
         
      
    
    
    public static void main(String args[]){
         new Feedback("");
    
}
}

    